package com.shikong.model;

import com.shikong.weather.Wdata;

public interface InformCallback {

	public void  onFinish(Wdata wdata);
}
