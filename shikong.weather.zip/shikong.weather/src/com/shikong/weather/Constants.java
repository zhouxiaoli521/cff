package com.shikong.weather;

import com.amap.api.maps.model.LatLng;

public class Constants {

	public static final int POISEARCH = 1000;

	public static final int ERROR = 1001;
	public static final int FIRST_LOCATION = 1002;

	public static final int ROUTE_START_SEARCH = 2000;
	public static final int ROUTE_END_SEARCH = 2001;
	public static final int ROUTE_SEARCH_RESULT = 2002;
	public static final int ROUTE_SEARCH_ERROR = 2004;

	public static final int REOCODER_RESULT = 3000;
	public static final int DIALOG_LAYER = 4000;
	public static final int POISEARCH_NEXT = 5000;

	public static final int BUSLINE_RESULT = 6000;
	public static final int BUSLINE_DETAIL_RESULT = 6001;
	public static final int BUSLINE_ERROR_RESULT = 6002;

	public static final LatLng BEIJING = new LatLng(39.90403, 116.407525);// �����о�γ��
	public static final LatLng SHANGHAI = new LatLng(31.239879, 121.499674);// �Ϻ��о�γ��
	public static final LatLng CHENGDU = new LatLng(30.679879, 104.064855);// �ɶ��о�γ��
	public static final LatLng XIAN = new LatLng(34.341568, 108.940174);// �����о�γ��
	public static final LatLng ZHENGZHOU = new LatLng(34.7466, 113.625367);// ֣���о�γ��
}
