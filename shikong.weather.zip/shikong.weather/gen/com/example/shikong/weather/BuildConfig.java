/** Automatically generated file. DO NOT MODIFY */
package com.example.shikong.weather;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}